import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Login } from '../../models/login';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  login: Login = new Login();

  constructor(private authService: AuthService, private router: Router) {}

  loginSubmit() {
    console.log(JSON.stringify(this.login));

    this.authService.loginUser(this.login).subscribe(
      (res) => {
        console.log('User Logged in successfully Successfully');
        this.router.navigate(['/dashboard']);
        console.log(JSON.stringify(res));
        localStorage.setItem('token', res.token);
      },
      (err) => {
        console.log('login fail');
      }
    );
  }
  ngOnInit(): void {}
}
