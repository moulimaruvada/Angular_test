import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Register } from '../../models/register';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit {
  register: Register = new Register();

  constructor(private authService: AuthService, private router: Router) {}

  registerSubmit() {
    const newUser: any = {
      name: this.register.name,
      email: this.register.email,
      password: this.register.password,
    };

    this.authService.registerUser(newUser).subscribe(
      (res) => {
        console.log('User registered Successfully');
        this.router.navigate(['/dashboard']);
        console.log(JSON.stringify(res));
        localStorage.setItem('token', res.token);
      },
      (err) => {
        console.log('register fail');
      }
    );
  }
  ngOnInit(): void {}
}
