import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProfileFormsRoutingModule } from './profile-forms-routing.module';
import { CreateProfileComponent } from './components/create-profile/create-profile.component';
import { HttpClientModule } from '@angular/common/http';
import { httpInterceptorProviders } from '../core/interceptor';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [CreateProfileComponent],
  imports: [
    CommonModule,
    HttpClientModule,
    FormsModule,
    ProfileFormsRoutingModule,
  ],
  providers: [httpInterceptorProviders],
})
export class ProfileFormsModule {}
