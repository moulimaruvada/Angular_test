import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CreateProfile } from '../../models/create-profile';
import { ProfileFormsService } from '../../services/profile-forms.service';

@Component({
  selector: 'app-create-profile',
  templateUrl: './create-profile.component.html',
  styleUrls: ['./create-profile.component.css'],
})
export class CreateProfileComponent implements OnInit {
  createProfile: CreateProfile = new CreateProfile();
  constructor(
    private profileFormsService: ProfileFormsService,
    private router: Router
  ) {}

  createProfileSubmit() {
    this.profileFormsService.createProfile(this.createProfile).subscribe(
      (res) => {
        console.log('success');
        this.router.navigate(['/dashboard']);
      },
      (err) => {
        console.log(JSON.stringify(err));
      }
    );
  }

  ngOnInit(): void {}
}
