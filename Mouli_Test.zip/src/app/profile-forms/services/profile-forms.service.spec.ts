import { TestBed } from '@angular/core/testing';

import { ProfileFormsService } from './profile-forms.service';

describe('ProfileFormsService', () => {
  let service: ProfileFormsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProfileFormsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
