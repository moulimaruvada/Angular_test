import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ProfilesService {
  constructor(private httpClient: HttpClient) {}

  showProfiles(): Observable<any> {
    return this.httpClient.get('/api/profiles');
  }
  loadProfiles(): Observable<any> {
    return this.httpClient.get('/api/profile');
  }
}
