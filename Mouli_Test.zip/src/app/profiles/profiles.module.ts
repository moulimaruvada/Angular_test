import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProfilesRoutingModule } from './profiles-routing.module';
import { ProfileItemComponent } from './components/profile-item/profile-item.component';
import { ProfilesComponent } from './components/profiles/profiles.component';
import { HttpClientModule } from '@angular/common/http';
import { httpInterceptorProviders } from '../core/interceptor';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [ProfileItemComponent, ProfilesComponent],
  imports: [CommonModule, HttpClientModule, FormsModule, ProfilesRoutingModule],
  providers: [httpInterceptorProviders],
})
export class ProfilesModule {}
